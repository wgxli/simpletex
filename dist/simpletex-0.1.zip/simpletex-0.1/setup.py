from setuptools import setup, find_packages

setup(name='simpletex',
      version='0.1',
      description='Latex Document Generation',
      author='Samuel Li',
      author_email='samuel.wgx@gmail.com',
      packages=find_packages()
     )
